public enum FoodType {
    MEAT, HAY, PEANUTS, FISH

}
