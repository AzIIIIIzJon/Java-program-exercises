public enum AnimalType {

    LION, ELEPHANT, PENGUIN
}
