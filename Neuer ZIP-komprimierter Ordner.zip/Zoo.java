public class Zoo {

    public static void main(String[] args) {



        Food food ;
        Animal animal;



        System.out.println(food.getAmount());

    }


}
